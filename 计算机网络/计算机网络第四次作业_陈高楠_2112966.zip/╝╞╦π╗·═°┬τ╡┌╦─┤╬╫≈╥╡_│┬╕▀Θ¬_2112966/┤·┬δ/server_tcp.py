from socket import *
import sys

# 服务器端通过调用socket()创建套接字来启动一个服务器
serverSocket = socket(AF_INET, SOCK_STREAM)
server_address = ('127.0.0.1', 5998)  # 接收传入的ip地址与端口号
# 服务器调用bind()绑定指定服务器的套接字地址（IP 地址 + 端口号）
serverSocket.bind(server_address)
# 服务器调用listen()做好侦听准备，同时规定好请求队列的长度
Length = 1024
try:
    serverSocket.listen(1)
except socket.error:
    print("fail to listen on port %s" % error)
    sys.exit(1)
while True:
    print("Ready to server...")
    # 服务器进入阻塞状态，等待客户的连接请求
    # 服务器通过accept来接收连接请求，并获得客户的 socket 地址
    connectionSocket, addr = serverSocket.accept()
    try:
        # 通过TCP 套接字接收 HTTP 请求
        message = connectionSocket.recv(Length).decode('utf-8')
        print('file msg from client: ' + message)
        # 收到客户端断开连接消息
        if message == 'disconnect': break
        # 从服务器的文件系统读取客户端请求的文件
        print(message)
        filename = message.split()[1]
        filename = filename.lstrip('/')
        file = open(filename, "rb")
        content=file.read()
        # 被请求文件存在，创建一个由被请求的文件组成的“请求成功”HTTP 响应报文
        response = "HTTP/1.1 200 OK\r\n\r\n"
        connectionSocket.send(response.encode("utf-8"))
        file.close()
        connectionSocket.send(content)
    except IOError:
        response = "HTTP/1.1 404 NOT FOUND\r\n\r\n"
        connectionSocket.send(response.encode("utf-8"))
        connectionSocket.send("<h1>404 NOT FOUND</h1>".encode("utf-8"))
        # 被请求文件不存在，创建“请求目标不存在”HTTP 响应报文
print("finish test, close connect")
# 通过close()关闭套接字
connectionSocket.close()
serverSocket.close()