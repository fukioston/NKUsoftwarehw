import base64
from socket import *
# 你好，我今晚在写计算机网络的作业。借你邮箱一用。虽然你不是你，你是我，我是你，我的意思是你邮箱本来就是我的。你好像就是我。
endMsg = "\r\n.\r\n"
# 选择一个邮件服务
# IAXNKIKRNRSPUQJR
mailServer = "smtp.126.com"
# 发送方地址和接收方地址，from 和 to
fromAddress = "fukioston@126.com"
toAddress = input("请输入你要发送的邮箱：")
msg = input("请输入你要发送的内容：")
msg="\r\n"+msg
# "2112966@mail.nankai.edu.cn"
# 1125102571@qq.com
encodefromAddress = base64.b64encode(fromAddress.encode('utf-8'))
username = str(encodefromAddress, 'utf-8')  # 将发件人邮箱进行编码
passcode = "IAXNKIKRNRSPUQJR"
encodepasscode = base64.b64encode(passcode.encode('utf-8'))
password = str(encodepasscode, 'utf-8')  # 将授权码进行编码


# 创建客户端套接字并建立连接
serverPort = 25  # SMTP使用25号端口
clientSocket = socket(AF_INET, SOCK_STREAM)
clientSocket.connect((mailServer, serverPort))
# 从客户套接字中接收信息
recv = clientSocket.recv(1024).decode()
print(recv)
if '220' != recv[:3]:
    print('220 reply not received from server.')

# 发送 HELO 命令并且打印服务端回复
# 开始与服务器的交互，服务器将返回状态码250,说明请求动作正确完成
heloCommand = 'HELO Alice\r\n'
print(heloCommand)
clientSocket.send(heloCommand.encode())  # 随时注意对信息编码和解码
recv1 = clientSocket.recv(1024).decode()
print(recv1)
if '250' != recv1[:3]:
    print('250 reply not received from server.')

# 发送"AUTH LOGIN"命令，验证身份.服务器将返回状态码334（服务器等待用户输入验证信息）
print('AUTH LOGIN\r\n')
clientSocket.sendall('AUTH LOGIN\r\n'.encode())
recv2 = clientSocket.recv(1024).decode()
print(recv2)

# 发送验证信息
print(username + '\r\n')
clientSocket.sendall((username + '\r\n').encode())
recvName = clientSocket.recv(1024).decode()
print(recvName)

print(password + '\r\n')
clientSocket.sendall((password + '\r\n').encode())
recvPass = clientSocket.recv(1024).decode()
print(recvPass)
# 如果用户验证成功，服务器将返回状态码235


# TCP连接建立好之后，通过用户验证就可以开始发送邮件。邮件的传送从MAIL命令开始，MAIL命令后面附上发件人的地址。
# 发送 MAIL FROM 命令，并包含发件人邮箱地址
print('MAIL FROM: <' + fromAddress + '>\r\n')
clientSocket.sendall(('MAIL FROM: <' + fromAddress + '>\r\n').encode())
recvFrom = clientSocket.recv(1024).decode()
print(recvFrom)


# 接着SMTP客户端发送一个或多个RCPT (收件人recipient的缩写)命令，格式为RCPT TO: <收件人地址>。
# 发送 RCPT TO 命令，并包含收件人邮箱地址，返回状态码 250
print('RCPT TO: <' + toAddress + '>\r\n')
clientSocket.sendall(('RCPT TO: <' + toAddress + '>\r\n').encode())
recvTo = clientSocket.recv(1024).decode()  # 注意UDP使用sendto，recvfrom
print(recvTo)


# 发送 DATA 命令，表示即将发送邮件内容。服务器将返回状态码354（开始邮件输入，以"."结束）
print('DATA\r\n')
clientSocket.send('DATA\r\n'.encode())
recvData = clientSocket.recv(1024).decode()
print(recvData)


# 编辑邮件信息，发送数据
subject = "我喜欢计算机网络！！！！".encode('utf-8')
contentType = "text/plain; charset=UTF-8"

message = 'from:' + fromAddress + '\r\n'
message += 'to:' + toAddress + '\r\n'
message += 'subject:' + "=?utf-8?B?" + base64.b64encode(subject).decode() + '?=\r\n'
message += 'Content-Type:' + contentType + '\r\n'
message += '\r\n' + msg
print(message)
clientSocket.sendall(message.encode())

# 以"."结束。请求成功返回 250
clientSocket.sendall(endMsg.encode())
recvEnd = clientSocket.recv(1024).decode()
print(recvEnd)
if '250' != recvEnd[:3]:
    print('250 reply not received from server')

# 发送"QUIT"命令，断开和邮件服务器的连接
print('QUIT\r\n')
clientSocket.sendall('QUIT\r\n'.encode())
recvEnd = clientSocket.recv(1024).decode()
print(recvEnd)
clientSocket.close()

