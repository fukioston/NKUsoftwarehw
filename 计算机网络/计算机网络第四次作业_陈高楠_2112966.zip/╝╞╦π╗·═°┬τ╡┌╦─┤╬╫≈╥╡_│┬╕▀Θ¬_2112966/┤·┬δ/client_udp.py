# -*- coding: UTF-8 -*-
from socket import*
import time
#客户端调用socket()创建套接字
clientSocket=socket(AF_INET,SOCK_DGRAM)
#使用settimeout函数限制recvfrom()函数的等待时间为1秒
clientSocket.settimeout(1)
count=0
start=0
totaltime=0
for i in range(10):
    print("test_"+str(i))
    t1=time.perf_counter()
    clientSocket.sendto("ping".encode("utf-8"),("127.0.0.1",7777))
    try:
        message,address=clientSocket.recvfrom(1024)
    except:
        print("out of time!!!")
        count=count+1
        continue
    t2=time.perf_counter()
    if start==0:
        mintime=(t2-t1)/2
        maxtime=(t2-t1)/2
        start=1
    elif((t2-t1)/2<mintime):
        mintime=(t2-t1)/2
    elif((t2-t1)/2>maxtime):
        maxtime=(t2-t1)/2
    totaltime=totaltime+(t2-t1)/2
    print('%.15f'%((t2-t1)/2))
print('min_RRT:'+str(mintime))
print('max_RRT:'+str(maxtime))
print('average_RRT:'+str(totaltime/(10-count)))
print('packet loss rate:'+str(count/10))